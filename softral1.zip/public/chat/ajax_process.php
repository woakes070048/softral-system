<?php

include("chat-config.php");

echo $_POST['name'];

if (isset($_SESSION['id']) && isset($_POST['name'])) {

    $chattype = htmlspecialchars($_POST['chattype']);
    $sendto = htmlspecialchars($_POST['sendto']);
    $groupid = htmlspecialchars($_POST['groupid']);
    $msg = htmlspecialchars($_POST['name']);

    
    echo $chattype;


    if ($chattype == 'individual') {
        // Individual Chatting
        if ($msg != "") {
            $sql = $dbh->prepare("INSERT INTO chat_messages (sender_id,reciever_id,msg,msg_type, posted) VALUES (?,?,?,'file',NOW())");
            echo $sql->execute(array($_SESSION['id'], $sendto, $msg));
        }
    } else {
        // Group Chatting
        if ($msg != "") {
            $sql = $dbh->prepare("INSERT INTO chat_group_messages (grp_id,sender_id,msg,msg_type,posted) VALUES (?,?,?,'file',NOW())");
            echo $sql->execute(array($groupid, $_SESSION['id'], $msg));
        }
    }
}






//    if ($edit == 0) {
//        
//    } else {
//        $sql_ask = "update msg_chat set msg = '$message' where m_id = $edit";
//    }
//
//    $sql_ask = "insert into msg_chat(s_id,r_id,msg, msg_type, added_date) values(" . $s_id33 . "," . $r_id33 . ",'" . $name . "', 'file', NOW())";
//
//$result_ask = @mysql_query($sql_ask);
//echo $result_ask;
?>