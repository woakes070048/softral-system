<footer>
    <div class="container">
      <div class="row">
        <div class="col-md-4 column">
          <div id="text-2" class="widget widget_text">
            <div class="textwidget">
              <p><img src="<?= $websiteRoot ?>/images/logo.png" alt="Byron" /></p>
				<p>
				<?php
				if($personalConfiguration->footerBlock1 != null)
					echo $personalConfiguration->footerBlock1;
				else 
					echo $globalConfiguration->footerBlock1;
				?>
				</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 column">
          <div id="recent-posts-4" class="widget widget_recent_entries">
            <h3 class="widget-title">Recent Posts</h3>
		    <ul>
				<?= $main->getLatestBlogs($GLOBALS['user_id']) ?>
            </ul>
          </div>
        </div>
        <div class="col-md-4 column">
          <div id="md_widget_dribbble-2" class="widget widget_md_widget_dribbble">
            <h3 class="widget-title">Contact Us</h3>
            <p><i class="fa fa-map-marker"></i>
				<?php
				if($personalConfiguration->footerContactUsAddress != null)
					echo $personalConfiguration->footerContactUsAddress;
				else echo $globalConfiguration->footerContactUsAddress;
				?>
			</p>
            <p><i class="fa fa-phone"></i>
				<?php
				if($personalConfiguration->footerPhoneNumber != null)
					echo $personalConfiguration->footerPhoneNumber;
				else echo $globalConfiguration->footerPhoneNumber;
				?>
			</p>
            <p><i class="fa fa-envelope"></i>
				<?php
				if($personalConfiguration->footerMailId != null)
					echo $personalConfiguration->footerMailId;
				else echo $globalConfiguration->footerMailId;
				?>
			</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <div id="copyright">
    <div class="container">
      <div id="copyright-text">Copyright @ 2015 All Rights Are Reserved. NetNoor Blog</div>      
    </div>
       <?php
        include("scroll_arrow.php");
        ?>
  </div>