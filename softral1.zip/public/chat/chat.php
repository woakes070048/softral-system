<?php
//include("header.php");
?>
  <link href="<?= $websiteRoot; ?>css/style.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/animate.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/wp.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/css-generate.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/fonts.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/chat-chat.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/emoticons.css" rel="stylesheet" type="text/css"/>
        <link href="<?= $websiteRoot; ?>css/fileupload/styles.css" rel="stylesheet" type="text/css"/>
        <!--<link href="/css/ucstyle.css" rel="stylesheet" type="text/css"/>-->
        
        
        
        <link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">
        <script type='text/javascript' src="<?= $websiteRoot; ?>js/jquery-1.11.1.js"></script> <!--jQuery Main Library -->

<div id="wrap">

    <?php
    //include("top_menu.php");
    ?>

    <?php
    //include("mob_menu.php");
    ?>
    <?php
    //include("banner.php");
    ?>

    <div class="clearfix"></div>
    <div class="page-content padding-small" id="home-container">
        <div class="container">
            <div class="chat md-column col-md-12">
                <div class="row">
                    <!--                    <div class="profilepic col-xs-3">
                                            <img width="35px" height="35px" src="http://localhost/netnoor/images/man.png" style="margin-right:5px;">
                    
                                            Sibbir Ahmed
                                            <img width="16px" height="16px" src="http://localhost/netnoor/images/active.png" style="margin-right:5px;"> 
                                            <input type="text" style="padding: 4px 12px; border: 1px solid #b4b4b4; border-radius:6px; width:100% !important; margin-top: 11px;" placeholder="Search" value="" name="text-info">
                                            <p>
                                                <span class="home home-menu">Home</span> |
                                                <span class="recent home-menu">Recent</span> |
                                                <span class="contacts home-menu">Contacts</span> |
                                                <span class="groups home-menu">Groups</span>
                                            </p>
                                        </div>
                                        <div class="profilepic col-xs-8">
                                            <img width="35px" height="35px" src="http://localhost/netnoor/images/man.png" style="margin-right:5px;">
                    
                    
                                            <p>
                                                Med Noor <img width="16px" height="16px" src="http://localhost/netnoor/images/active.png" style="margin-right:5px;"> <br>
                                                English . 11 am. Mobile, Alabama
                                            </p>
                                            <input type="text" style="padding: 4px 12px; border: 1px solid #b4b4b4; border-radius:6px; width:100% !important; margin-top: 11px;" placeholder="Search" value="" name="text-info">
                    
                                        </div>-->
                </div>
                <div class="row">
                    <div class="chatbox-left-panel col-xs-3">
                        <div class="chat-header chattingwith">
                            <img width="35px" height="35px" style="margin-right:5px;" src="<?= $websiteRoot ?>images/man.png">

                            <?php echo $_SESSION['user-name'];?>
                            <p class="hide">User Type  <input type="text"  value="" name="usertype" class="form-control" id="usertype"></p>
                            <img width="10px" height="10px" style="margin-right:5px;" src="<?= $websiteRoot ?>images/active.png"> 
                            <p class="row"> 
                                <!--<input id="chatbox-left-panel-search" type="text" name="text-info" value="" placeholder="Search" style="padding: 4px 12px; border: 1px solid #b4b4b4; border-radius:6px; width:100% !important; margin-top: 11px;">-->
                                <input class="col-xs-9" id="chatbox-left-panel-search" type="text" name="text-info" value="" placeholder="Search" style="padding: 4px 12px; border: 1px solid #b4b4b4; border-radius:6px; margin-top: 11px;">
                                <select id="search_from" name="search_from" class="col-xs-3" style="padding: 7px 12px; border: 1px solid #b4b4b4; border-radius:6px; margin-top: 11px;">
                                    <option value="netnoor_db">Netnoor Directory</option>
                                    <option value="my_contacts">My Contacts</option>
                                </select>
                            </p>
                            <p class="chat-header-menu">
                                <span class="home">Home</span> |
                                <span class="recent">Recent</span> |
                                <span class="contacts">Contacts</span> |
                                <span class="groups">Groups</span> |
                                <span class="pending-requests">Pending Request<sup id="no-of-pending-request">*</sup></span>
                            </p>



                            <div class="col-xs-12" id="all-netnoor-user">

                                <!--                                <h4 class="online_green">Results from Netnoor</h4>
                                                                <div class="user"><img width="35px" height="35px" src="http://localhost/netnoor/images/man.png" style="margin-right:5px;"> Dinesh Gangwar  <label class="userid hide">3</label></div>
                                                                <div class="user"><img width="35px" height="35px" src="http://localhost/netnoor/images/man.png" style="margin-right:5px;"> Vikash Sisodia  <label class="userid hide">4</label></div>
                                                                <div class="user"><img width="35px" height="35px" src="http://localhost/netnoor/images/man.png" style="margin-right:5px;"> Brain  <label class="userid hide">5</label></div>-->
                            </div>


                        </div>
                        <div class="users col-xs-12">
                            <?php
                            $usertype = 'recent';
                            ?>
                            <?php include("chat-users.php"); ?>
                        </div>
                    </div>


                    <div class="chatbox col-xs-9">
                        <?php
                        if (isset($_SESSION['id'])) {
                            include("chat-chatbox.php");
                        } else {
                            //IF user is not logedin 
                            header('Location:' . $websiteRoot);
                            exit();
                        }
                        ?>
                    </div>


                </div>


            </div>

        </div>
    </div>
    <?php
    include("footer.php");
    ?>

    <?php
    //include("scroll_arrow.php");
    ?>

</div>
<!-- CLOSE WRAP -->
<!--<script src="//code.jquery.com/jquery-latest.js"></script>-->

<script type="text/javascript">var base_url = "<?= $websiteRoot ?>";</script>
<script src="<?= $websiteRoot; ?>js/chat-chat.js"></script>

<!--Smiley-->
<script src="<?= $websiteRoot; ?>js/emoticons.js"></script> 
<!--//Smiley-->

<!-- Copy, Edit and Delete Message  -->
<link href="<?= $websiteRoot; ?>css/skins/cm_blue/style.css" rel="Stylesheet" type="text/css" />
<script type="text/javascript" src="<?= $websiteRoot; ?>js/jquery.jeegoocontext-2.0.0.js"></script>
<!--// Copy, Edit and Delete Message  -->



<!--JavaScript used to call the fileupload widget to upload files--> 
<script src="<?= $websiteRoot; ?>js/fileupload/jquery.ui.widget.js"></script>
<script src="<?= $websiteRoot; ?>js/fileupload/jquery.iframe-transport.js"></script>
<script src="<?= $websiteRoot; ?>js/fileupload/jquery.fileupload.js"></script>

<script>
    
    // When the server is ready...
    $(function () {
        'use strict';
        // Define the url to send the image data to
        //var url = "uploads/files.php";
        var base_url = "<?php echo $websiteRoot; ?>";
        var url = base_url + "uploads/files.php";
        
        // Call the fileupload widget and set some parameters
        $('#fileupload').fileupload({
            url: url,
            dataType: 'json',
            done: function (e, data) {
                // Add each uploaded file name to the #files list
                $.each(data.result.files, function (index, file) {
                    // Update Database....
                    // Display Image..
                    
                    var chattype = $("#chattype").val();
                    var sendto = $("#sendto").val();
                    var groupid = $("#groupid").val();
                    //var usertype = $("#usertype").val();
                                        
                    //var dataString = 'name='+file.name+'&chattype='+chattype+'&sendto='+sendto+'&groupid='+groupid+'&usertype='+usertype;
                    var dataString = 'name='+file.name+'&chattype='+chattype+'&sendto='+sendto+'&groupid='+groupid;
                    
                    
                    if(file.error){
                        alert(file.error);
                        $('#progress').hide();
                    }else{
                        $.ajax({
                            type: "POST",
                            url: base_url + 'ajax_process.php',
                            data: dataString,
                            cache: true,
                            success: function(html){
                                if(file.error){
                                    //alert(file.error);
                                    /*
                                alert("aaaaaa");
                                //
                                if(file.error == 'Filetype not allowed'){
                                    bootbox.alert("Filetype not allowed! <br> Only .jpg, .jpeg, .png or .bmp files are allowed", function() {
                                        //Example.show("Hello world callback");
                                    });
                                }
                                else if(file.error == 'File is too big'){
                                    //File is too big
                                    bootbox.alert("File is too big<br> Maximum file size is 2MB", function() {
                                        //Example.show("Hello world callback");
                                    });
                                }
                                else if(file.error == 'The uploaded file exceeds the post_max_size directive in php.ini'){
                                    //File is too big
                                    bootbox.alert("File is too big<br> Maximum file size is 2MB", function() {
                                        //Example.show("Hello world callback");
                                    });
                                }
                                     */
                                }
                                else{
                                    //$("#img-profilepic").attr('src', 'timthumb.php?src=uploads/files/' + file.name);
                                    $('#progress').hide();
                                    //$('#profileimg').val(file.name);
                                    //$('#profileimg_status').text("");
                                }
                            }  
                        });
                    }
                    
                    
                                    
                });
            },
            progressall: function (e, data) {
                // Update the progress bar while files are being uploaded
                $('#progress').show();
                var progress = parseInt(data.loaded / data.total * 100, 10);
                $('#progress .bar').css('width', progress + '%');
            }
        });
    });
</script>
<!--//JavaScript used to call the fileupload widget to upload files--> 

</body>
</html>