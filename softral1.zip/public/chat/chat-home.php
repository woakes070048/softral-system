<center>
    <div class="watermark">
        <h2><span class="online_green">Netnoor<br> A Social Network with Security and Privacy</span></h2>
        <p><span style="color:#2f4f4f;">Add Friends, Make Groups and discuss with freedom, security and privacy. Enjoy the Text &nbsp;Chat, Audio and Video calls with superior quality</span></p>


        <p style="margin-top: 50px;"><input type="text" style="padding: 12px 40px; border: 1px solid #b4b4b4; border-radius:6px; width:60% !important" placeholder="Tell your friends what you are upto" value="" name="text-info"></p>
    </div>
</center> 