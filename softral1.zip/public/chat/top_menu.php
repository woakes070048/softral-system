<?php
    //$websiteRoot = 'http://localhost/netnoor/';
  $banners = $main->fetchAllHomeBannerId();
  $sliderConfiguration = $main->fetchSliderConfigurationDetails(1);
  $sliderHeight = null;
  $sliderWidth = null;
  if($sliderConfiguration != null)
  {
    if($sliderConfiguration->sliderHeight != 0)
      $sliderHeight = $sliderConfiguration->sliderHeight;
    if($sliderConfiguration->sliderWidth != 0)
      $sliderWidth = $sliderConfiguration->sliderWidth;
  }
?>
<header id="header">
    <div class="header-content" id="header-content">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div id="logo"> <a href="<?= $_SESSION['netnoor']['pageRoot'] ?>"> <img src="<?php echo $websiteRoot;?>images/logo.png" alt="" /> </a> </div>
                </div>
                <div class="col-md-4 col-md-offset-5 col-sm-5 col-sm-offset-4 col-xs-12 search_bar">
                    <?php include("search.php"); ?>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="clearfix"></div>

<div class="banner_nav">
  <div class="container">
    <div class="row">
      <div class="col-md-12 banner">
        <div class="col-md-9 col-sm-9 col-xs-12 banner_left padding_none">
          <div class="col-md-12 col-sm-12 col-xs-12 navigation padding_none">
              <?php if(isset($_SESSION['id'])) {?>
              <!--<div style="float:right;line-height:initial;padding:5px 10px;background-color:#000;color:#fff">
                  <?php 
                      //$uid = $_SESSION['id'];
                      
                      //$sql1 = "SELECT * FROM tbl_users where id='$uid'";  
                                  //echo $result1 = mysql_query($sql1);
                      //while($row = mysql_fetch_array($result1)) {
                      //  print_r($row);
                      //echo $row["addedOn"];
                      //}
                      ?>
                  Hi <?= $_SESSION['user-name'].', '.date('m-d-Y h:i A') ?>,
                  <a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/change_password">Change Password</a>
              </div>!-->
              <?php
                  }
                  ?>

              <nav class="navbar navbar-default" id="header-menu">
                    <div class="container-fluid"> 
                      <!-- Brand and toggle get grouped for better mobile display -->
                      <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                      </div>
                      
                      <!-- Collect the nav links, forms, and other content for toggling -->
                      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul id="menu-header-menu" class="nav navbar-nav">
                          <li class="current_page_item" id="lnkHome"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>">HOME</a></li>
                          <li id="lnkCategories"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/categories">CATEGORIES</a></li>
                          <li id="lnkRSSFeeds"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/rss_feed">RSS FEEDS</a></li>
						  <li id="lnkChat"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/chat">Chat</a></li>
                          <?php if(!isset($_SESSION['id'])) {?>
                          <li id="lnkLogin"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/News">NEWS</a></li>
                          <li id="lnkRegister"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/Terms and Conditions">Terms And Conditions</a></li>
                          <?php } else { ?>
                          <li id="lnkAddBlog"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/add_blog">Add Blog</a></li>
                          <li id="lnkManageBlog"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/blog_listing">Manage Blog</a></li>
						  
                          <li id="lnkContact"><a href="<?= $websiteRoot ?><?= $_REQUEST['adminId'] ?>/contact">CONTACT</a></li>
                       
                          <?php } ?>
                        </ul>
                        
                      </div>
                      <!-- /.navbar-collapse --> 
                    </div>
                    <!-- /.container-fluid --> 
              </nav>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
</div>

