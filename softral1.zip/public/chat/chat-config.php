<?php 
if (!isset($dbh)) {
	
    $db_host = "localhost"; // Hostname

    //if($_SERVER['SERVER_NAME'] == 'localhost'){
    if($_SERVER['SERVER_NAME'] == 'www.netnoor.com' || $_SERVER['SERVER_NAME'] == 'netnoor.com'){
        $db_user = "netnoor_sibbir"; //MySQL Username Here
        $db_pass = "&Z70y2hW_5XH";   //MySQL Password Here
        $websiteRoot = 'http://www.netnoor.com/';
    }
    else{
        
        $db_user = "root";      //MySQL Username Here
        $db_pass = "";          //MySQL Password Here
        //$websiteRoot = 'http://localhost/netnoor/';
        $websiteRoot = "http://localhost:81/client_projects/softral1/chat/";
        
    }
    
    
    $db   = "softral1"; // Database Name
    
    
    //$dbh  = new PDO('mysql:dbname='.$db.';host='.$host.';port='.$port,$user,$pass);
    $dbh = new PDO('mysql:dbname=' . $db . ';host=' . $db_host . ';', $db_user, $db_pass);

 
}
?>