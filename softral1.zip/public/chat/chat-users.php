<?php
include_once("config.php");


//date_default_timezone_set("Asia/Kolkata");
date_default_timezone_set("America/Chicago");
$timezone = new DateTimeZone('America/Chicago');


if (!isset($usertype))
    $usertype = (!empty($_GET['usertype']) ? $_GET['usertype'] : 'home');


/**
 * Recent Messages Section
 * ---------------------------------------------------------------------------------------
 */
$class_usertype = ($usertype == 'recent' || $usertype == 'home' ? '' : ' hide');

echo "<div id='recent-user' class='all-conversation$class_usertype'>";
     

echo "<h4 class='online_green'>Recent Message</h4>";
$sql = $dbh->prepare("SELECT m1.*,
                        IF(m1.sender_id={$_SESSION['id']}, m1.reciever_id ,m1.sender_id) as conversation_id,
                        IF(m1.sender_id={$_SESSION['id']}, t2.email ,t1.email) as conversation_name,
                        IF(m1.sender_id={$_SESSION['id']}, t2.online_status ,t1.online_status ) as conversation_online_status,
                        IF(m1.sender_id={$_SESSION['id']}, t2.last_seen ,t1.last_seen ) as conversation_last_seen
                        FROM ( SELECT * FROM chat_messages AS c WHERE c.sender_id = '{$_SESSION['id']}' OR c.reciever_id = '{$_SESSION['id']}' ORDER BY c.id DESC ) AS m1 
                        inner join users as t1 on m1.sender_id = t1.id 
                        inner join users as t2 on m1.reciever_id = t2.id 
                        GROUP BY LEAST( m1.sender_id, m1.reciever_id) , GREATEST( m1.sender_id, m1.reciever_id ) 
                        ORDER BY m1.id DESC");
$sql->execute();

while ($r = $sql->fetch()) {

    /**
     * Time Calculation
     */
    $date = new DateTime($r['conversation_last_seen']);
    $last_seen = $date->format('Y-m-d H:i:s') . "\n";


    $now = new DateTime();
    $current_time = $now->format('Y-m-d H:i:s') . "\n";


    $difference = $date->diff($now);

    //$diff = $difference->format('%h hours %i minutes %s seconds');
    $hour = $difference->format('%h');
    $min = $difference->format('%i');


    /**
     * End of section
     * Time Calculation
     */
    $online_img = "";
    if ($r['conversation_online_status'] == 'on') {

        if ($hour > 0 || $min > 1) {
            $sql = $dbh->prepare("UPDATE users SET online_status = 'off'  WHERE id={$r['conversation_id']}");
            $sql->execute();
        } else {
            $online_img = "<img width='10px' height='10px' style='margin-right:5px;' src='{$websiteRoot}images/active.png'>";
        }
    }
    if ($r['conversation_online_status'] == 'away') {

        if ($hour > 0 || $min > 1) {
            $sql = $dbh->prepare("UPDATE users SET online_status = 'off'  WHERE id={$r['conversation_id']}");
            $sql->execute();
        } else {
            $online_img = "<img width='16px' height='16px' style='margin-right:5px;' src='{$websiteRoot}images/away.png'>";
        }
    }

    $profile_pic = "";
    // TODO@ Check Gender for default Profile Picture

    $profile_pic = "<img width='35px' height='35px' style='margin-right:5px;' src='{$websiteRoot}images/man.png'>";
    echo "<div class='user'>$profile_pic <span class='username'>{$r['conversation_name']}</span> $online_img <label class='userid hide'>{$r['conversation_id']}</label></div>";
}

echo "</div>";


/**
 * End of
 * Recent Messages Section
 */
/**
 * All users Section
 * --------------------------------------------------------------------------------------------------------------
 */
$class_usertype = ($usertype == 'contacts' ? '' : ' hide');


echo "<div id='all-user' class='all-conversation{$class_usertype}'>";
echo "<h4 class='online_green'>List of Users</h4>";

$sql = $dbh->prepare("SELECT a.id, a.user_id, a.friend_id, a.status, 
            IF(a.user_id={$_SESSION['id']}, c.id, b.id) as conversation_id,
            IF(a.user_id={$_SESSION['id']}, c.email, b.email) as name,
            IF(a.user_id={$_SESSION['id']}, c.online_status, b.online_status) as online_status
            FROM chat_friendlist a 
            inner join users b on a.user_id = b.id 
            inner join users c on a.friend_id = c.id 
            where (user_id = {$_SESSION['id']} or friend_id={$_SESSION['id']}) and a.status='accepted'");
$sql->execute();
while ($r = $sql->fetch()) {
    $online_img = "";
    if ($r['online_status'] == 'on') {
        $online_img = "<img width='10px' height='10px' style='margin-right:5px;' src='{$websiteRoot}images/active.png'>";
    }

    if ($r['online_status'] == 'away') {
        $online_img = "<img width='10px' height='10px' style='margin-right:5px;' src='{$websiteRoot}images/away.png'>";
    }

    $profile_pic = "";
    // TODO@ Check Gender for default Profile Picture

    $profile_pic = "<img width='35px' height='35px' style='margin-right:5px;' src='{$websiteRoot}images/man.png'>";


    echo "<div class='user'>$profile_pic <span class='username'>{$r['name']}</span> $online_img <label class='userid hide'>{$r['conversation_id']}</label></div>";
}
echo "</div>";



/**
 * End of
 * All users Section
 */
/**
 * Groups Name
 * ------------------------------------------------------------------------------------------------
 */
$class_usertype = ($usertype == 'groups' ? '' : ' hide');

echo "<div id='all-groups' class='all-conversation{$class_usertype}'>";

$groups_seetings_icon = "<img width='20px' height='20px' style='margin-right:5px;' src='{$websiteRoot}images/user_group_settings.png'>";
echo "<h4 class='online_green'>Groups 
            <a href='{$websiteRoot}chat-new-group.php'>$groups_seetings_icon</a> 
        </h4>";

?>
<!--<a href='<?= $websiteRoot ?>home/chat-new-group'>Create/Edit Group</a>-->
<?php
$sql = $dbh->prepare("SELECT * from chat_usergroup where users LIKE '%" . $_SESSION['id'] . "%'");
$sql->execute();

while ($r = $sql->fetch()) {

    $profile_pic = "";
    // TODO@ Check Gender for default Profile Picture
    $profile_pic = "<img width='35px' height='35px' style='margin-right:5px;' src='{$websiteRoot}images/grp.png'>";

    echo "<div class='group'>$profile_pic {$r['grp_name']}<label class='groupid hide'>{$r['id']}</label></div>";
}
echo "</div>";

/**
 * End of
 * Groups Name
 */
/**
 * Pending Friend Request
 */
$class_usertype = ($usertype == 'pendind_request' ? '' : ' hide');

echo "<div id='all-pending-requests' class='all-conversation{$class_usertype}'>";
echo "<h4 class='online_green'>Pending Request</h4>";

$sql = $dbh->prepare("SELECT a.id, a.user_id, a.status, b.email FROM chat_friendlist a inner join users b on a.user_id = b.id where friend_id = {$_SESSION['id']} and a.status='requested'");
$sql->execute();
while ($r = $sql->fetch()) {
    $online_img = "";

    $profile_pic = "";
    // TODO@ Check Gender for default Profile Picture
    $profile_pic = "<img width='35px' height='35px' style='margin-right:5px;' src='{$websiteRoot}images/man.png'>";


    echo "<div class='pending-request'>$profile_pic 
                <span class='username'>{$r['name']}</span> 
                <label class='userid hide'>{$r['user_id']}</label>
          </div>";
}
echo "</div>";
/*
 * End of Section
 * Pending Friend Request
 */



/**
 * --------------------------------------------------------------------------------------------
 */
//Send an activation Message to the server

$now = new DateTime();
$now->setTimezone($timezone);
$last_seen = $now->format('Y-m-d H:i:s') . "\n";



$sql = $dbh->prepare("UPDATE users SET online_status = 'on', last_seen = '$last_seen' WHERE id={$_SESSION['id']}");
$sql->execute();
?>








<script>
    /**
     * Select user from My contact list to start aconversation
     * and to see the previous conversation
     */
    $(".user").on("click", function(){
        
        $(".request").addClass("hide");
        $("#friend-request").removeClass("hide");
        $("#send-box").removeClass("hide");
        $("#chattype").val('individual');
        $("#sendto").val(($(this).find("label").text()));
        $("#groupid").val("");
        
        $("#friend_rquest_user_name").html(($(this).find(".username").text()));
        $("#friend_request_user_id").val(($(this).find(".userid ").text()));
        
        load_new_stuff();
    });
    
    
    /**
     * End of Section
     * Select user from My contact list to start aconversation
     * and to see the previous conversation
     */
    
    
    /**
     * Select a group from my Group list to start aconversation
     * and to see the previous conversation
     */
    $(".group").on("click", function(){
        
        $(".friend-header").addClass("hide");
        $("#friend-intro").removeClass("hide");
        $("#send-box").removeClass("hide");
        $("#chattype").val('group');
        $("#groupid").val(($(this).find("label").text()));
        $("#sendto").val("");
        
        load_new_stuff();
    });
    
    /**
     * End of Section
     * Select a group from my Group list to start aconversation
     * and to see the previous conversation
     */
    
    
    //TODO@ Check Where I can shift this block.
    $(".user, .group").on("click", function(){
        $(".fileinput-button").removeClass("hide");     
    });
    
    
    
    
    /**
     * Select user to accept/reject pending friend Request
     */
    $(".pending-request").on("click", function(){
        $("#friend-request").removeClass("hide");
        $(".request").addClass("hide");
        $("#reponse-friend-request").removeClass("hide");
        $("#friend_rquest_user_name").html(($(this).find(".username").text()));
        $("#friend_request_user_id").val(($(this).find(".userid ").text())); 
    });
    /**
     * End ofo Section
     * Select user to accept/reject pending friend Request
     */
</script>