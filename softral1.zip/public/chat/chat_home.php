<?php
$act_id = 'home';
//include_once("include/dbconnection.php");
//include('classes/database.php');
//include('classes/main.php');
include_once("include/validate.php");

		//@mysql_connect('localhost','root','') OR die("Failed to Connectinggg MYSQL");
		@mysql_connect('localhost','netnoor_sibbir','&Z70y2hW_5XH') OR die("Failed to Connecting MYSQL");
		@mysql_select_db('netnoor_blog') OR die("Failed to connect database");
//include("vline/classes/Vline.php");
//include("vline/includes/JWT.php");
//print_r($_SESSION);
// $vline = new Vline();
// $vline->setUser($_SESSION['userid'], $_SESSION['username']);
// $vline->init();
include("profile_upload_image.php");
if (isset($_POST['action']) && ($_POST["action"] == "profile-edit")) {

//All Columns
    $all_columns[] = "firstname";
    $all_columns[] = "lastname";
    $all_columns[] = "email";
    $all_columns[] = "birth_date";
    $all_columns[] = "gender";
    $all_columns[] = "country";
    $all_columns[] = "city";
    $all_columns[] = "language";
    $all_columns[] = "mobile";
    $all_columns[] = "username";
    $all_columns[] = "password";
    $all_columns[] = "company_name";
    $all_columns[] = "company_size";

    //Get All values to insert in to table
    $fname = addslashes($_POST["firstname"]);
    $lname = addslashes($_POST["lastname"]);
    //$all_values[]=addslashes($_POST["email"]);
    //$all_values[]=addslashes($_POST["birth_date"]);
    $gender = addslashes($_POST["gender"]);
    $country = addslashes($_POST["country"]);
    $city = addslashes($_POST["city"]);
    $mobile = addslashes($_POST["mobile"]);
    //$all_values[]=addslashes($_POST["city"]);
    $lang = addslashes($_POST["language"]);
    //$all_values[]=addslashes($_POST["mobile"]);
    //$all_values[]=addslashes($_POST["username"]);
    //$all_values[]=addslashes($_POST["password"]);
    $cmp_nm = addslashes($_POST["company_name"]);
    $cmp_size = addslashes($_POST["company_size"]);
    $pro_pic = $_FILES['pro_pic'];
    $user_edit_id = $_SESSION['userid'];
    $sql_sel = "select * from tbl_users where userid = '$user_edit_id'";
    $res_sel = mysql_query($sql_sel) or die(mysql_error());
    $row_sel = mysql_fetch_assoc($res_sel);
    if ($pro_pic['name'] != '') {
        $path_img = uploadImg('pro_pic', 'profile_img');
    } else {
        $path_img = $row_sel['pro_pic'];
    }
    //echo "<pre>";
    //print_r($_POST);
    //print_r($_FILES);
    //print_r($_SESSION);
    //echo "</pre>";
    $_SESSION['pro_pic'] = $path_img;

    $sql_upd = "UPDATE `tbl_users` SET `firstname`= '$fname',`lastname`= '$lname',`gender`= '$gender',`language`= '$lang',
        `country`= '$country', `city`='$city', `mobile`='$mobile', 
        `company_name`= '$cmp_nm', `company_size`='$cmp_size', `pro_pic`= '$path_img' WHERE userid = '$user_edit_id' ";
    //echo $sql_upd."<br>";
    $res_upd = mysql_query($sql_upd) or die(mysql_error());

    //header("location:home.php?msg=success");
}
?>


            <script type="text/javascript" src="js/jquery-1.10.1.min.js"></script> 
           
            <script type="text/javascript">
                 //alert('start');
                
            </script>

	<link rel="stylesheet" href="../css/chat-style.css" type="text/css" />
            <link href="../css/dashboard.css" rel="stylesheet">
			<link href="../css/dashboard-home.css" rel="stylesheet">
                <link href="css/contact-Profile.css"  rel="stylesheet">
                    <link href="../css/modal-css.css"  rel="stylesheet">

                        <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
                            <script src="//code.jquery.com/jquery-1.10.2.js"></script>
                            <script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
                            <script src="js/jquery.form.min.js"></script>

                            <script type="text/javascript" src="../js/emoticons.js"></script>
                            <link href="../css/emoticons.css" rel="stylesheet" type="text/css"/>

                            <link rel="stylesheet" href="/resources/demos/style.css">

            
     <link href="../css/skins/cm_blue/style.css" rel="Stylesheet" type="text/css" />
     <script type="text/javascript" src="../js/jquery.jeegoocontext-2.0.0.js"></script>

	<link rel="stylesheet" type="text/css" href="../css/fileupload/styles.css">
    <link rel="stylesheet" type="text/css" href="../css/mystyle.css">                           
     <style type="text/css">
                                        
                                        .btn_add{
                                            padding: 5px 30px;
                                            background-color: rgb(0, 175, 240);
                                            border-radius: 14px;
                                            border: medium none;
                                            color: #FFF !important;
                                            font-weight: 600;	
                                            margin-top: 10px !important;
                                        }
                                        .hide{
                                            display:none;
                                        }

                                        .user1
                                        {
                                            display:block;
                                            padding:5px;
                                            background-color:#e1f2fe;
                                            float:left;
                                            width:74%;
                                            border-radius:5px;
                                            margin:5px 0px 5px 40px;

                                        }
                                        .user1_time{
                                            float: left;
                                            margin-left: 10px;
                                            margin-top: 10px;
                                            width: 11%;
                                        }
                                        .user2
                                        {
                                            display:block;
                                            padding:5px;
                                            /*background-color:#b9e1ff;*/
                                            background-color:#d5f7f7;
                                            float:left;
                                            /*		width:90%;*/
                                            width:80%;
                                            border-radius:5px;
                                            margin:5px 0px 5px 10px;
                                        }

                                        .chat-area ,.grp-chat-area
                                        {
                                            text-align:left;
                                        }
                                        .contact-main-div {
                                            background-color: #bf4027;
                                            border:none;
                                            border-radius:0px;
                                            margin:0 auto;
                                            max-width:100% !important;
                                            padding: 2% 0;
                                            width: 100%;
                                        }
                                        .fa-user
                                        {line-height:2;}
                                        .active
                                        {
                                            
                                            background: rgba(27, 199, 13, 0.63) none repeat scroll 0% 0%;
                                            color: #FFF;
                                        }

                                        .chat-area-right{
                                            position: absolute !important;
                                            right: 0px !important;
                                            bottom: 0px !important;
                                            width: 285px !important;
                                            display: block !important;
                                            z-index: 10000 !important;
                                            padding: 10px 0px !important;	
                                        }
                                        .send-message-right{
                                            z-index: 100000 !important;
                                            position: absolute !important;
                                            right: 0px !important;
                                            margin-top: -15px !important;
                                            bottom:15px !important;
                                        }
                                        

                                    </style>                              
                                       
	<script type="text/javascript">    
                                        //if (!name || name === ' ') {
                                        //var name = "<? echo $_SESSION["firstname"] . ' ' . $_SESSION["lastname"] ?>";	
                                        //}
    	
                                        // strip tags
                                        //name = name.replace(/(<([^>]+)>)/ig,"");
    	
                                        // display name on page
                                        //$("#name-area").html("You are: <span>" + name + "</span>");
    	
                                        // kick off chat
                                        // var chat =  new Chat();
                                        $(function() {
    	
                                            //chat.getState(); 
    		 
    		 
                                            // watch textarea for key presses
                                            jQuery("#sendie").keydown(function(event) {  
             
                                                var key = event.which;  
           
                                                //all keys including return.  
                                                if (key >= 33) {
                   
                                                    var maxLength = $(this).attr("maxlength");  
                                                    var length = this.value.length;  
                     
                                                    // don't allow new content if length is maxed out
                                                    if (length >= maxLength) {  
                                                        event.preventDefault();  
                                                    }  
                                                }  
                                            });
                                            // watch textarea for release of key press
                                            jQuery('#sendie').keyup(function(e) {	
    		 					 
                                                if (e.keyCode == 13) { 
    			  
                                                    var text = $(this).val();
                                                    var maxLength = $(this).attr("maxlength");  
                                                    var length = text.length; 
                     
                                                    // send 
                                                    if (length <= maxLength + 1) { 
                     
                                                        chat.send(text, name);	
                                                        jQuery(this).val("");
    			        
                                                    } else {
                    
                                                        jQuery(this).val(text.substring(0, maxLength));
    					
                                                    }
                                                }
                                            });
                                            jQuery('#search_user').keyup(function(){
                                                var ip_val = jQuery('#search_user').val();
                                                if(ip_val!="")
                                                {
                                                    jQuery('.cont_bar').hide();
                                                    jQuery('#clr_srch').show();
                                                    jQuery('#load_img1').show();
                                                    var user_srch = jQuery(this).val();
                                                    var dataload={'user_srch1':user_srch};
                                                    jQuery.post("../user_check.php", dataload, function(html){
                                                        //alert(html);
                                                        jQuery(".res_div1").show();
                                                        jQuery(".res_div1").html(html);
                                                        jQuery('#load_img1').hide();
                                                    });
                                                }
                                                else
                                                {
                                                    jQuery('#clr_srch').hide();
                                                    jQuery(".res_div1").hide();
                                                    jQuery('.tabli').show();
                                                    jQuery('#recent-1').show();	
                                                }
                                            });
                                            jQuery('.tab').click(function(){
                                                var iid=jQuery(this).attr('id');
                                                jQuery('.tablist').addClass('hide');
                                                //alert("Hi");
                                                jQuery('#'+iid+'-1').removeClass('hide');
                                            });
                                            jQuery('#clr_srch').click(function(){
                                                jQuery("#load_img1").hide();
                                                jQuery(".res_div1").hide();
                                                jQuery('.tabli').show();
                                                jQuery('#recent-1').show();
                                                jQuery('#search_user').val('');
                                                jQuery('#clr_srch').hide();
                                            });

                                            jQuery('.li_user').click(function(){
                                                jQuery(".li_user").removeClass("active");
                                                jQuery(this).addClass("active");				
                                            });
                                            /*jQuery('#chat-area').scroll(function(){
                                                                alert(JSON.stringify(jQuery(this))
                                                                jQuery(this).scrollTop();
                                                                /*var caht_div = document.getElementById("chat-area");
                                                        caht_div.scrollTop = caht_div.scrollHeight;
				
                                                        })	*/
				
				
			
			
                                        });
                                    </script>
								
		<script>
                                    
                                        function scrollToBottom(id){
                                            div_height = $("#"+id).height();
                                            div_offset = $("#"+id).offset().top;
                                            window_height = $(window).height();
                                            $('html,body').animate({
                                                scrollTop: div_offset-window_height+div_height
                                            },'slow');
                                        }
                                        function user_click(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'aaa111':aaa[1]};
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                //alert(html);
                                                //jQuery("#user1").html(aaa[1]);
			 
                                                jQuery(".column2").html(html);
                                            });
                                        }
                                        function show_member_grp()
                                        {
                                            var s_id = '<?php echo $_SESSION["userid"]; ?>';
                                            var u_name = jQuery('#user_nm'+s_id).html();
                                            var dataload={'show_member':s_id};
                                            jQuery.post("user_check.php", dataload, function(html){
                                                jQuery(".wrp_users-css").show();
                                                jQuery(".wrp_users-css").html(html);
                                            });
                                        }
                                        function asd()
                                        {
                                            //alert('asdasd');
                                            jQuery('.wrp_users-css').hide();
                                        }
                                        function grp_frm_sbmt(e)
                                        {
                                            //alert('hi');
                                            jQuery.ajax({
                                                type: "POST",
                                                url: 'grp_create.php',
                                                data: jQuery(e).serialize(), // serializes the form's elements.
                                                success: function(data)
                                                {
                                                    // alert(data); // show response from the php script.
                                                    location.reload();
                                                }
                                            });
                                            return false;
                                        }
                                    
                                    
            
                                        function shw_grp_name()
                                        {
                                            jQuery("#btn1111").hide();
                                            jQuery("#btn2222").show();
                                        }
	
                                        function user_click_chat(e)
                                        {
                                            var timezone = jstz.determine();
                                            //alert(timezone.name());
                                        
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var s_id = '<?php echo $_SESSION["userid"]; ?>';
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'user_chat':aaa[1]};
                                        
                                            var asd = jQuery('#usernm_'+aaa[1]).closest('li');
                                        
                                        
                                           // alert('uChat@'+asd);
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                //console.log(html)
                                                jQuery(".column2").html(html);
                                            
                                                //                                            var caht_div = document.getElementById("chat-area");
                                                //                                            caht_div.scrollTop = caht_div.scrollHeight;
                                                //                                            
                                                //alert("aaaaaaaa");
                                                jQuery("#s_id").val(s_id);
                                                jQuery("#r_id").val(aaa[1]);
                                                var r_id111 = jQuery('#r_id').val();
                                                load_data = {'r_id11':r_id111, 'timezone': timezone.name()};
												//alert(r_id111);
                                            
                                                //var timer = setTimeout(function(){
                                                var timer = setInterval(function(){
                                                    //alert("aaaaaaaaaa");
                                                
                                                    //jQuery('.chat-area').html("Loading....");
                                                    jQuery.post('../get_instant_mess.php', load_data,  function(data) { //alert(data);
                                                        jQuery('.chat-area').html(data);
                                                        //caht_div.scrollTop = caht_div.scrollHeight;
                                                        //$( "#chat-area" ).scroll();
                                                        //caht_div.scrollTop = caht_div.scrollHeight;
                                                    });
                                                }, 1000);
                                            
                                                setTimeout(function(){
                                                    var caht_div = document.getElementById("chat-area");
                                                    caht_div.scrollTop = caht_div.scrollHeight;
                                                
                                                    //                                                alert("aaaaaaaaa");
                                                    //                                                $.post('get_script.php', load_data,  function(data) {
                                                    //                                                    jQuery('.chat-area1').html(data);
                                                    //                                                    //caht_div.scrollTop = caht_div.scrollHeight;
                                                    //                                                    //$( "#chat-area" ).scroll();
                                                    //                                                    //caht_div.scrollTop = caht_div.scrollHeight;
                                                    //                                                });
                                                
                                                }, 4001);
                                            
                        
                                                //                        caht_div.scrollTop = caht_div.scrollHeight;
                        
                                                //                                                                                        $.post('get_instant_mess.php', load_data,  function(data) {
                                                //                                                                                            jQuery('.chat-area').html(data);
                                                //                                                                                            var caht_div = document.getElementById("chat-area");
                                                //                                                                                            caht_div.scrollTop = caht_div.scrollHeight
                                                //                                                                                        });
			
                                            });
                
                
                                            //                                        caht_div.scrollTop = caht_div.scrollHeight;
		
                                            /*if(asd.hasClass('active')){
                                                        alert('true')
                                                        $('.chat-area').addClass('chat-area-right')
                                                        $('#send-message-area').addClass('send-message-right')
                                                        $('#sendie').css('margin-bottom','15px')
                                                 }else{
                                                         $('.chat-area').removeClass('chat-area-right')
                                                         $('#send-message-area').removeClass('send-message-right')
                                                         $('#sendie').css('margin-bottom','15px')
                                                        // alert('false') 
                                                 }*/
                            
                                        }
	
                                        function group_click_chat(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_"); //alert('grp@'+aaa[1]);
                                            var dataload={'grp_chat':aaa[1]};
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                jQuery("#g_id").val(aaa[1]);
                                                jQuery(".column2").html(html);
                                                load_data = {'g_id11':aaa[1]};
                                                
                                                var timer1 = setInterval(function(){
                                                    jQuery.post('../get_instant_gr_mess.php', load_data,  function(data) {
                                                        jQuery('.grp-chat-area').html(data);
                                                    });
                                                }, 1000);
                        
                                                jQuery.post('../get_instant_gr_mess.php', load_data,  function(data) {
                                                    jQuery('.grp-chat-area').html(data);
                                                });
                         
                                                var caht_div = document.getElementById("chat-area");
                        
                                                caht_div.scrollTop = caht_div.scrollHeight;
                                            });
		
                                        }

                                        function user_click_accept(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'acpt_req':aaa[1]}; //alert(aaa+'###'+u_name);
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                //alert(html);
                                                //$("#user1").html(aaa[1]);
                                                jQuery(".column2").html(html);
                                            });
                                        }
                                        function acpt_contacts(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'acpt_contact':aaa[1]};
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                //alert(html);
                                                //$("#user1").html(aaa[1]);
                                                jQuery(".column2").html(html);
                                                jQuery("#contact_"+aaa[1]).html('');
                                            });
                                        }
                                        function decli_contacts(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'decli_contact':aaa[1]};
                                            jQuery.post("../user_check.php", dataload, function(html){
                                                location.reload();
                                            });
                                        }
                                        function profile_details(e)
                                        {
                                            var user_nm = e.className;
                                            var aaa = user_nm.split("_");
                                            var dataload={'view_contact':aaa[2]};
                                            jQuery.post("profile.php", dataload, function(html){
                                                jQuery(".modal-body").html(html);
                                                return true;
                                            });
                                        }
                                        function profile_details1(e)
                                        {
                                            var user_nm = e.className;
                                            var aaa = user_nm.split("_");
                                            var dataload={'view_contact':aaa[2]};
                                            jQuery.post("profile.php", dataload, function(html){
                                                jQuery(".column2").html(html);
                                                return true;
                                            });
                                        }
                                        function profile_edit(e)
                                        {
                                            var user_nm = e.className;
                                        
                                        
                                            var aaa = user_nm.split("_");
                                     
                                            var dataload={'user_id':aaa[2]};
                                            jQuery.post("profile_update.php", dataload, function(html){
                                                jQuery(".column2").html(html);
                                                return true;
                                            });
                                        }
                                        function contact_edit(e){
                                            var dataload= "";
                                            jQuery.post("contact_update.php", dataload, function(html){
                                                jQuery(".column2").html(html);
                                                return true;
                                            });
                                        }
                                    
                                        function add_contacts(e)
                                        {
                                            var user_nm = e.id;
                                            var aaa = user_nm.split("_");
                                            var u_name = jQuery('#user_nm'+aaa[1]).html();
                                            var dataload={'add_contact':aaa[1]};
                                            jQuery.post("user_check.php", dataload, function(html){
                                                jQuery("#chat-area").html(html);
                                                jQuery("#contact_"+aaa[1]).html('');
                                            });
                                        }
        
                                        //                                    $(".('click', function(){
                                        //                                       alesendie_m").on('click', function(){
                                        //                                       alert("aaaaaaa");
                                        //                                    });
                                        //                                    $('.sendie1').live('keypress', function (e) {
                                        //                                        alert("aaaaaaa");
                                        ////                                        if(e.which === 13){
                                        ////                                            alert("aaaaaaa");
                                        ////                                        }
                                        ////                                        alert("bbbbbbb");
                                        ////                                        e.prventDefault();
                                        //                                    });
   
                                        function showbox(){
                                            //alert("bbbbbbb");
                                        
                                            //                                        var caht_div = document.getElementById("chat-area");
                                            //                                            caht_div.scrollTop = caht_div.scrollHeight;


                                            var definition = {"smile":{"title":"Smile","codes":[":)",":=)",":-)"]},"sad-smile":{"title":"Sad Smile","codes":[":(",":=(",":-("]},"big-smile":{"title":"Big Smile","codes":[":D",":=D",":-D",":d",":=d",":-d"]},"cool":{"title":"Cool","codes":["8)","8=)","8-)","B)","B=)","B-)","(cool)"]},"wink":{"title":"Wink","codes":[":o",":=o",":-o",":O",":=O",":-O"]},"crying":{"title":"Crying","codes":[";(",";-(",";=("]},"sweating":{"title":"Sweating","codes":["(sweat)","(:|"]},"speechless":{"title":"Speechless","codes":[":|",":=|",":-|"]},"kiss":{"title":"Kiss","codes":[":*",":=*",":-*"]},"tongue-out":{"title":"Tongue Out","codes":[":P",":=P",":-P",":p",":=p",":-p"]},"blush":{"title":"Blush","codes":["(blush)",":$",":-$",":=$",":\">"]},"wondering":{"title":"Wondering","codes":[":^)"]},"sleepy":{"title":"Sleepy","codes":["|-)","I-)","I=)","(snooze)"]},"dull":{"title":"Dull","codes":["|(","|-(","|=("]},"in-love":{"title":"In love","codes":["(inlove)"]},"evil-grin":{"title":"Evil grin","codes":["]:)",">:)","(grin)"]},"talking":{"title":"Talking","codes":["(talk)"]},"yawn":{"title":"Yawn","codes":["(yawn)","|-()"]},"puke":{"title":"Puke","codes":["(puke)",":&",":-&",":=&"]},"doh!":{"title":"Doh!","codes":["(doh)"]},"angry":{"title":"Angry","codes":[":@",":-@",":=@","x(","x-(","x=(","X(","X-(","X=("]},"it-wasnt-me":{"title":"It wasn't me","codes":["(wasntme)"]},"party":{"title":"Party!!!","codes":["(party)"]},"worried":{"title":"Worried","codes":[":S",":-S",":=S",":s",":-s",":=s"]},"mmm":{"title":"Mmm...","codes":["(mm)"]},"nerd":{"title":"Nerd","codes":["8-|","B-|","8|","B|","8=|","B=|","(nerd)"]},"lips-sealed":{"title":"Lips Sealed","codes":[":x",":-x",":X",":-X",":#",":-#",":=x",":=X",":=#"]},"hi":{"title":"Hi","codes":["(hi)"]},"call":{"title":"Call","codes":["(call)"]},"devil":{"title":"Devil","codes":["(devil)"]},"angel":{"title":"Angel","codes":["(angel)"]},"envy":{"title":"Envy","codes":["(envy)"]},"wait":{"title":"Wait","codes":["(wait)"]},"bear":{"title":"Bear","codes":["(bear)","(hug)"]},"make-up":{"title":"Make-up","codes":["(makeup)","(kate)"]},"covered-laugh":{"title":"Covered Laugh","codes":["(giggle)","(chuckle)"]},"clapping-hands":{"title":"Clapping Hands","codes":["(clap)"]},"thinking":{"title":"Thinking","codes":["(think)",":?",":-?",":=?"]},"bow":{"title":"Bow","codes":["(bow)"]},"rofl":{"title":"Rolling on the floor laughing","codes":["(rofl)"]},"whew":{"title":"Whew","codes":["(whew)"]},"happy":{"title":"Happy","codes":["(happy)"]},"smirking":{"title":"Smirking","codes":["(smirk)"]},"nodding":{"title":"Nodding","codes":["(nod)"]},"shaking":{"title":"Shaking","codes":["(shake)"]},"punch":{"title":"Punch","codes":["(punch)"]},"emo":{"title":"Emo","codes":["(emo)"]},"yes":{"title":"Yes","codes":["(y)","(Y)","(ok)"]},"no":{"title":"No","codes":["(n)","(N)"]},"handshake":{"title":"Shaking Hands","codes":["(handshake)"]},"skype":{"title":"Skype","codes":["(skype)","(ss)"]},"heart":{"title":"Heart","codes":["(h)","<3","(H)","(l)","(L)"]},"broken-heart":{"title":"Broken heart","codes":["(u)","(U)"]},"mail":{"title":"Mail","codes":["(e)","(m)"]},"flower":{"title":"Flower","codes":["(f)","(F)"]},"rain":{"title":"Rain","codes":["(rain)","(london)","(st)"]},"sun":{"title":"Sun","codes":["(sun)"]},"time":{"title":"Time","codes":["(o)","(O)","(time)"]},"music":{"title":"Music","codes":["(music)"]},"movie":{"title":"Movie","codes":["(~)","(film)","(movie)"]},"phone":{"title":"Phone","codes":["(mp)","(ph)"]},"coffee":{"title":"Coffee","codes":["(coffee)"]},"pizza":{"title":"Pizza","codes":["(pizza)","(pi)"]},"cash":{"title":"Cash","codes":["(cash)","(mo)","($)"]},"muscle":{"title":"Muscle","codes":["(muscle)","(flex)"]},"cake":{"title":"Cake","codes":["(^)","(cake)"]},"beer":{"title":"Beer","codes":["(beer)"]},"drink":{"title":"Drink","codes":["(d)","(D)"]},"dance":{"title":"Dance","codes":["(dance)","\o/","\:D/","\:d/"]},"ninja":{"title":"Ninja","codes":["(ninja)"]},"star":{"title":"Star","codes":["(*)"]},"mooning":{"title":"Mooning","codes":["(mooning)"]},"finger":{"title":"Finger","codes":["(finger)"]},"bandit":{"title":"Bandit","codes":["(bandit)"]},"drunk":{"title":"Drunk","codes":["(drunk)"]},"smoking":{"title":"Smoking","codes":["(smoking)","(smoke)","(ci)"]},"toivo":{"title":"Toivo","codes":["(toivo)"]},"rock":{"title":"Rock","codes":["(rock)"]},"headbang":{"title":"Headbang","codes":["(headbang)","(banghead)"]},"bug":{"title":"Bug","codes":["(bug)"]},"fubar":{"title":"Fubar","codes":["(fubar)"]},"poolparty":{"title":"Poolparty","codes":["(poolparty)"]},"swearing":{"title":"Swearing","codes":["(swear)"]},"tmi":{"title":"TMI","codes":["(tmi)"]},"heidy":{"title":"Heidy","codes":["(heidy)"]},"myspace":{"title":"MySpace","codes":["(MySpace)"]},"malthe":{"title":"Malthe","codes":["(malthe)"]},"tauri":{"title":"Tauri","codes":["(tauri)"]},"priidu":{"title":"Priidu","codes":["(priidu)"]}};
                                            $.emoticons.define(definition);
                                        
                                            var caht_div = document.getElementById("chat-area");
                                            caht_div.scrollTop = caht_div.scrollHeight;
                                            
                                            
                                            
                                            var s_id = jQuery('#s_id').val();
                                            var r_id = jQuery('#r_id').val();
                                            var imessage = jQuery('#sendie').val();
                                            var edit = jQuery('#js-emaillink-edit').val();
                                        
                                            var textWithEmoticons = $.emoticons.replace(imessage);
                                        
                                            imessage = textWithEmoticons;
                                        
                                        
                                            var post_data = {'r_id33':r_id,'s_id33':s_id,'message':imessage, 'edit':edit};
                                        
                                            //                                        var caht_div = document.getElementById("chat-area");
                                            //                                        caht_div.scrollTop = caht_div.scrollHeight;
                                        
                                            jQuery.post('mess.php', post_data, function(data) {
                                                jQuery(data).hide().appendTo('.chat-area').fadeIn();
                                                //                                            var caht_div = document.getElementById("chat-area");
                                                //                                            caht_div.scrollTop = caht_div.scrollHeight;
                                                //scrollToBottom('chat-area');
                                                jQuery('#sendie').val('');
                                                jQuery('#js-emaillink-edit').val('');
                                                //                                            var caht_div = document.getElementById("chat-area");
                                                //                                            caht_div.scrollTop = caht_div.scrollHeight;
                                            }).fail(function(err){ 
                                            });
                                        
                                            setTimeout(function(){
                                                //alert("aaaaaaaaaaaaa");
                                                var caht_div = document.getElementById("chat-area");
                                                caht_div.scrollTop = caht_div.scrollHeight + 1000;
                                            }, 2001);
                                                        
                                            //                                             var timezone = jstz.determine();
                                            //                                            alert("aaaaaa" + timezone);
                                            //                                            
                                            //                                        post_data = {'r_id11':r_id, 'timezone': timezone.name()};
                                            //                                        $.post('get_instant_mess.php', post_data, function(data) { 
                                            //                                            $('.chat-area').html(data);
                                            //                                            
                                            //                                            //alert("aaaaaaaaaaaaaa");
                                            //                                                                
                                            //                                            //var caht_div = document.getElementById("chat-area");
                                            //                                            //caht_div.scrollTop = caht_div.scrollHeight;
                                            //                                            
                                            //                                           setTimeout(function(){
                                            //                                            //alert("aaaaaaaaaaaaa");
                                            //                                                var caht_div = document.getElementById("chat-area");
                                            //                                                caht_div.scrollTop = caht_div.scrollHeight;
                                            //                                            }, 1111);
                                            //                                            
                                            //                                            
                                            //                                        });
                                        
                                        
                                            
                                            //                                        var caht_div = document.getElementById("chat-area");
                                            //                                            caht_div.scrollTop = caht_div.scrollHeight;
                                        
                                        
                                        }

                                        function showbox_grp(){
                                            var g_id = jQuery('#g_id').val();
                                            var s_id = '<?php echo $_SESSION["userid"]; ?>';
                                            var imessage = jQuery('#sendie_grp').val();
                                            var post_data = {'g_id33':g_id,'s_id33':s_id, 'grp_message':imessage};
                                            jQuery.post('mess.php', post_data, function(data) {
                                                jQuery(data).hide().appendTo('.grp-chat-area').fadeIn();
                                                var caht_div = document.getElementById("chat-area");
                                                caht_div.scrollTop = caht_div.scrollHeight;
                                                //scrollToBottom('chat-area');
                                                jQuery('#sendie_grp').val('');
                                            }).fail(function(err){ 
                                            });
                                            /*post_data = {'g_id11':g_id};
                                                $.post('get_instant_gr_mess.php', post_data, function(data) { 
                                                        $('.grp-chat-area').html(data);
                                                });*/
                                        }
                                    </script>

	<div class="dashbord-main-div col-md-12">
                                            <? //require_once("commonfiles/menu.php");  ?>

                                            <section>    
                                                <div style="width:100%; background-color:#ffffff; position:relative;"><!--#916b6b;-->


                                                    <!-- column 3 start -->
                                                    <?php
                                                    $sql_ad = "select * from tbl_ad_list order by ads_id desc";
//echo $sql_ad."<br>";
                                                    $res_ad = mysql_query($sql_ad) or die('kkkk'.mysql_error());
                                                    ?>
                                                    <div class="column3 col-md-2">
                                                        <div class="advertisement" style="overflow:hidden;  " >
                                                            <span class="close_ad">

<!--<img src="images/circle-close.png" style="position:absolute; left:220px; border:none !important; width:20px; height:20px; " /></span>-->
                                                                <img src="../images/circle-close.png" style="position:relative; left:80px; border:none !important; width:20px; height:20px; " /></span>
                                                            <ul style="margin:  0px;" class="   demo3 ">
                                                                <?php
                                                                while ($row_ad = mysql_fetch_assoc($res_ad)) {
                                                                    ?>
                                                                    <li class="  " style="width:100%; height:400px;" >
                                                                        <a href="javascript:void(0)" target="_blank" style="width:100%; height:400px;">
                                                                            <img src="../advert_img/<?php echo $row_ad['image']; ?>"  style="width:100%; height:400px !important; border-radius: 0px !important"  />
                                                                        </a>
                                                                    </li>
                                                                <?php } ?>
                                                            </ul>
                                                            <?php /* while($row_ad = mysql_fetch_assoc($res_ad)){ ?>
                                                              <img src="advert_img/<?php echo $row_ad['image']; ?>" style="height:400px; width:100%;" >
                                                              <?php } */ ?>
                                                        </div>
                                                    </div>
                                                    <!-- //column3 -->


                                                    <!--Chatting Section Start Here-->

                                                    <div class="column2 column2-2 col-md-7">
                                                        <div class="col-row">
                                                            <div class="row1">
                                                                <!--                                                            <h2>
                                                                                                                                Social Network is better with friends</h2>
                                                                                                                            
                                                                                                                            <p>Find your facebook friends on social network to chat and video call with them for free</p>-->

                                                                <?php
                                                                $system_messge = "select messege from custom_msg where title='CHAT_HOME_PAGE'";//echo $system_messge."<br>";
                                                                $res_system_messge = mysql_query($system_messge) or die(mysql_error());
                                                                while ($row_system_messge = mysql_fetch_assoc($res_system_messge)) {
                                                                    echo "<br>";
                                                                    echo $row_system_messge['messege'];
                                                                }
                                                                ?>

<!--<p><input type="button" id="fb-btn" name="fbbutton" value="Find facebook friends"></p>-->
                                                                <div class="pad3-0"></div>	
                                                                <p><input type="text" name="text-info" value="" placeholder="Tell your friends what you are upto"></p>
                                                            </div>
                                                        </div>

                                                        <div class="pad3-0"></div>
                                                        <div class="pad3-0"></div>
                                                        <div class="pad3-0"></div>

                                                        <!--<div class="col-row">
                                                                    <div class="row1"><h2>Your contacts hae not been active recenty..</h2>
                                                            <p><h2>You can post  your own status update or <a href="#">connect to facebbok</a> to see more news from your friends.</h2></p>
                                                            </div>
                                                        </div>-->
                                                    </div><!--column2-->

                                                    <!--Chatting Section End Here-->


                                                    
                                                    
                                                    

<!--###############################                 Online User Section Start Here                       ################-->

                                                    <div class="column1 col-md-3 nopadding">
                                                        <div class="col-row column1-list4 listing prof_hold">
                                                            <?php
                                                            $img_src;
                                                            $pro_pic = $_SESSION['pro_pic']; //echo $pro_pic."#hbmjhm";
                                                            if ($pro_pic == "") {
                                                                if ($_SESSION['gender'] == "M") {
                                                                    $img_src = "../images/man.png";
                                                                } else {
                                                                    $img_src = "../images/woman.png";
                                                                }
                                                            } else {
                                                                $img_src = "../profile_img/" . $pro_pic;
                                                            }
                                                            ?>
                                                            <ul>
															<li>
																<a href="#"><img width="40" height="40" src="<?php echo $img_src; ?>"></a>
																 <a href="#" class="fl_name_<?php //echo $userid;      ?>" onclick="return profile_details1(this);"><? echo $_SESSION["firstname"] . ' ' . $_SESSION["lastname"] ?></a>
															</li>
                                                                <!--<li style="" class="column1-profile-name col1-pad1">
                                                                    <a href="#" class="fl_name_<?php //echo $userid;      ?>" onclick="return profile_details1(this);"><? echo $_SESSION["firstname"] . ' ' . $_SESSION["lastname"] ?></a>
                                                                </li> -->
                                                                <li style="font-size: 12px;  margin: -10px 0 0 40px;"><img src="../images/active.png" width="10px" height="10px" style="margin-right:5px;"/> <span style="vertical-align:top;line-height:1.5;">Online</span></li>
                                                            </ul>
                                                            <div class="clearfix"></div>    
                                                        </div>
                                                        <input type="hidden" id="s_id" />
                                                        <input type="hidden" id="g_id" />
                                                        <input type="hidden" id="r_id" />
                                                        <div class="col-row dashboard-column1-list">
                                                            <ul>
                                                                    <!--<li><a href="#"><span style="margin-right:8%;"><i class="fa fa-search"></i></span><input type="text" id="search_user" style="margin: 5px !important;width: 74% !important;"/></a></li>-->
                                                                <li><a href="#" class="fl_name_<?php //echo $userid;       ?>" onclick="return profile_details1(this);"><span style="margin-right:8%;"><i class="fa fa-home"></i></span>Home</a></li>
                                                                <li><a href="call-phones.html"><span style="margin-right:8%;"><i class="fa fa-phone"></i></span>Call Phone</a></li>
                                                            </ul>
                                                        </div>   
                                                        <div class="col-row dashboard-column1-list">
                                                            <ul>
                                                                <!--<li style="border-bottom: 1px solid #ddd;"><a href="#"><span style="margin-right:0%;"><i class="fa fa-search"></i></span></a><input type="text" id="search_user" placeholder="Search"/><a href="javascript: void(0);" style="margin-left:5px;display:none;" id="clr_srch"><img src="../images/close_pop.png" /></a></li> -->
																<li style="border-bottom: 1px solid #ddd;"><input type="text" id="search_user" placeholder="Search"/><a href="javascript: void(0);" style="margin-left:5px;display:none;" id="clr_srch"><img src="../images/close_pop.png" /></a></li>
                                                            
														   </ul>
                                                        </div>         

                                                        <div class="col-row column1-list2 cont_bar tabli">
                                                            <ul><li><a href="#" id="contacts" class="tab">Contacts</a>
																	<a href="#" id="recent" class="tab">Recent</a>
																	<span><a href="#">All<span style="margin-left:6px;"><i class="fa fa-chevron-down"></i></span></a></span>
															</li>
                                                                <!--<li><a href="#" id="recent" class="tab">Recent</a></li>
                                                                <span><a href="#">All<span style="margin-left:6px;"><i class="fa fa-chevron-down"></i></span></a></span> -->
                                                            </ul>
                                                        </div>

                                                        <div class="col-row column1-list4 res_div" style="text-align:center;">
                                                            <img src="../images/ajax-loader.gif" style="display:none;width:20px;" id="load_img1">
                                                        </div>
                                                        <div class="col-row column1-list4 res_div1" style="text-align:center;">
                                                            <img src="../images/ajax-loader.gif" style="display:none;width:20px;" id="load_img1">
                                                        </div>


                                                        <div class="tablist hide cont_bar" id="contacts-1">
                                                            <div class="col-row" style="text-align:left;">
                                                            </div>
                                                            <?php
                                                            $user = $_SESSION["userid"];
                                                            $qry = "select * from tbl_friends_list where (frnd2='" . $user . "' or frnd1='" . $user . "') and status='A'";
                                                            //echo $qry;
															$res = mysql_query($qry);
//echo "<br>".mysql_num_rows($res)."<br>";
                                                            if (mysql_num_rows($res) > 0) {
                                                                while ($row1 = mysql_fetch_array($res)) {

                                                                    if ($row1['frnd2'] == $user) {
                                                                        $iid = $row1['frnd1'];
                                                                        //$qry1 = "select userid,username,pro_pic,gender from tbl_users where userid =" . $iid;
                                                                        $qry1 = "select users_id,username from tbl_users where users_id =" . $iid;
																		$res1 = mysql_query($qry1); //echo $qry1;
                                                                        $row = mysql_fetch_array($res1);
                                                                    } else {
                                                                        $iid = $row1['frnd2'];
                                                                        //$qry1 = "select userid,username,pro_pic,gender from tbl_users where userid =" . $iid;
                                                                        $qry1 = "select users_id,username from tbl_users where users_id =" . $iid;
																		$res1 = mysql_query($qry1); //echo $qry1;
                                                                        $row = mysql_fetch_array($res1);
                                                                    }
                                                                    $img_src;
                                                                    $pro_pic = $row['pro_pic'];
                                                                    if ($pro_pic == "") {
                                                                        //echo "Gender : ".$row['gender'];
                                                                        if ($row['gender'] == "M") {
                                                                            $img_src = "images/man.png";
                                                                        } else {
                                                                            $img_src = "images/woman.png";
                                                                        }
                                                                    } else {
                                                                        $img_src = "profile_img/" . $pro_pic;
                                                                    }
                                                                    ?>
                                                                    <div class="col-row column1-list4" style="text-align:left;">
                                                                        <ul>
                                                                            <li data-userid="<?php echo $row['users_id'] ?>" class="callbutton disabled <?php echo "user_" . $row['users_id']; ?>">
                                                                                <a href="#">
                                                                            <!--<img src="<?php echo $img_src; ?>" width="40" height="40" style="margin-right: 10px; float: left;border-radius:50%;"> <span style="line-height: 2.5;" class="user_nm" id="<?php echo "usernm_" . $row['users_id']; ?>" onclick="return user_click_chat(this);"><?php echo $row['username']; ?></span></a></li>-->
                                                                                    </ul>
                                                                                    <div class="clearfix"></div>    
                                                                                    </div>
                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                ?>
                                                                                <div class="col-row column1-list4" style="text-align:left;">
                                                                                    <ul>
                                                                                        <li>No Contacts yet.</li>
                                                                                    </ul>
                                                                                    <div class="clearfix"></div>    
                                                                                </div>
                                                                                <?php
                                                                            }
                                                                            ?>

                                                                            </div>



                                                                            <div class="tablist cont_bar" id="recent-1">
                                                                                <?php
                                                                                @session_start();
                                                                                $user = $_SESSION["userid"];
                                                                                $qry = "select * from tbl_friends_list where frnd2='" . $user . "' and status='P'"; //echo $qry ;
                                                                                $res = mysql_query($qry);
                                                                                if (mysql_num_rows($res) > 0) {
                                                                                    ?>
                                                                                    <div class="col-row" style="text-align:left;">
                                                                                        <span>Pending contact requests</span>
                                                                                    </div>

                                                                                    <?php
                                                                                    while ($row1 = mysql_fetch_array($res)) {
                                                                                        $iid = $row1['frnd1'];
                                                                                       // $qry = "select users_id,username,pro_pic,gender from tbl_users where users_id =" . $iid; echo $qry ;
																					    $qry = "select users_id,username from tbl_users where users_id =" . $iid; //echo $qry ;
                                                                                        $res = mysql_query($qry); //echo $qry;
                                                                                        $row = mysql_fetch_array($res);
                                                                                        $img_src;
                                                                                        $pro_pic = $row['pro_pic'];
                                                                                        if ($pro_pic == "") {
                                                                                            if ($row['gender'] == "M") {
                                                                                                $img_src = "../images/man.png";
                                                                                            } else {
                                                                                                $img_src = "../images/woman.png";
                                                                                            }
                                                                                        } else {
                                                                                            $img_src = "../profile_img/" . $pro_pic;
                                                                                        }
                                                                                        ?>
                                                                                        <div class="col-row column1-list4" style="text-align:left;">
                                                                                            <ul>
                                                                                                <li data-userid="<?php echo $row['users_id'] ?>" class="callbutton disabled <?php echo "user_" . $row['users_id']; ?>"><a href='#'><img src="<?php echo $img_src; ?>" width="40" height="40" style="margin-right: 10px; float: left;border-radius:50%;"> <span style="line-height: 2.5;" class="user_nm" id="<?php echo "usernm_" . $row['users_id']; ?>" onclick="return user_click_accept(this);"><?php echo $row['username']; ?></span></a></li>
                                                                                            </ul>
                                                                                            <div class="clearfix"></div>    
                                                                                        </div>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                                
                                                                                
                                                                                <div class="col-row" style="text-align:left;">
                                                                                    <span>Recent</span>
                                                                                </div>
                                                                                
                                                                                
                                                                                <?php
                                                                                $user = $_SESSION["userid"];
                                                                                $qry = "select * from tbl_friends_list where (frnd2='" . $user . "' or frnd1='" . $user . "') and status='A'";
                                                                                $res = mysql_query($qry); //echo $qry;
                                                                                //echo "<br>".mysql_num_rows($res)."<br>";
                                                                                if (mysql_num_rows($res) > 0) {
                                                                                    while ($row1 = mysql_fetch_array($res)) {
                                                                                        
//                                                                                        echo "<br>";
//                                                                                        echo $user;
                                                                                        
//                                                                                        echo "<pre>";
//                                                                                        print_r($row1);
                                                                                        

                                                                                        if ($row1['frnd2'] == $user) {
                                                                                            $iid = $row1['frnd1'];
//                                                                                            $qry1 = "select userid,username,pro_pic,gender from tbl_users where userid =" . $iid;
//                                                                                            $res1 = mysql_query($qry1);
//                                                                                            $row = mysql_fetch_array($res1);
                                                                                        } else {
                                                                                            $iid = $row1['frnd2'];
//                                                                                            $qry1 = "select userid,username,pro_pic,gender from tbl_users where userid =" . $iid;
//                                                                                            $res1 = mysql_query($qry1);
//                                                                                            $row = mysql_fetch_array($res1);
                                                                                        }
                                                                                       // $qry1 = "select userid,username,pro_pic,gender, online_status from tbl_users where userid =" . $iid;
																					    $qry1 = "select users_id,username from tbl_users where users_id =" . $iid;
                                                                                        $res1 = mysql_query($qry1);
                                                                                        $row = mysql_fetch_array($res1); //echo $qry1;
                                                                                        
                                                                                        //echo "<pre>";
                                                                                        //print_r($row);
                                                                                        
                                                                                        
                                                                                        
                                                                                        $img_src;
                                                                                        $pro_pic = $row['pro_pic'];
                                                                                        if ($pro_pic == "") {
                                                                                            //echo "Gender : ".$row['gender'];
                                                                                            if ($row['gender'] == "M") {
                                                                                                $img_src = "../images/man.png";
                                                                                            } else {
                                                                                                $img_src = "../images/woman.png";
                                                                                            }
                                                                                        } else {
                                                                                            $img_src = "../profile_img/" . $pro_pic;
                                                                                        }
                                                                                        ?>
                                                                                        <div class="col-row column1-list4 li_user" style="text-align:left;">
                                                                                            <ul>
                                                                                                <li data-userid="<?php echo $row['users_id'] ?>" class=" callbutton disabled <?php echo "user_" . $row['users_id']; ?>">
                                                                                                    <a href="#">
                                                                                                        <img src="<?php echo $img_src; ?>" width="40" height="40" style="margin-right: 10px; float: left;border-radius:50%;">
                                                                                                        <span style="line-height: 2.5;" class="user_nm" id="<?php echo "usernm_" . $row['users_id']; ?>" onclick="return user_click_chat(this);">
                                                                                                            <?php echo $row['username']; ?> 
                                                                                                            <?php 
                                                                                                            if($row['online_status'] == 1)
                                                                                                            {
                                                                                                                ?>
                                                                                                            <img width="16px" height="16px" style="margin-right:5px;" src="../images/active.png">
                                                                                                            <?php
                                                                                                            }    
                                                                                                            ?>
                                                                                                            
                                                                                                            
                                                                                                        </span>
                                                                                                    </a>
                                                                                                </li>
                                                                                            </ul>
                                                                                            <div class="clearfix"></div>    
                                                                                        </div>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    ?>
                                                                                    <div class="col-row column1-list4" style="text-align:left;">
                                                                                        <ul>
                                                                                            <li>No Contacts yet.</li>
                                                                                        </ul>
                                                                                        <div class="clearfix"></div>    
                                                                                    </div>
                                                                                    <?php
                                                                                }
                                                                                if (mysql_num_rows($res) > 0) {
                                                                                    $user = $_SESSION["userid"];
                                                                                    $qry = "select gn.g_id,gn.g_name from tbl_grp_name as gn where g_id IN (select grp_id from tbl_grp_usr where usr_id='" . $user . "')";
                                                                                    $res = mysql_query($qry);
                                                                                    //echo "<br>".mysql_num_rows($res)."<br>";
                                                                                    if (mysql_num_rows($res) > 0) {
                                                                                        while ($row1 = mysql_fetch_array($res)) {

                                                                                            $img_src = "../images/grp.jpeg";
                                                                                            ?>
                                                                                            <div class="col-row column1-list4 li_user" style="text-align:left;">
                                                                                                <ul>
                                                                                                    <li data-userid="<?php echo $row['users_id'] ?>" class="callbutton disabled <?php echo "user_" . $row1['g_id']; ?>"><a href="#"><img src="<?php echo $img_src; ?>" width="40" height="40" style="margin-right: 10px; float: left;border-radius:50%;"> <span style="line-height: 2.5;" class="user_nm" id="<?php echo "usernm_" . $row1['g_id']; ?>" onclick="return group_click_chat(this);"><?php echo $row1['g_name']; ?></span></a></li>
                                                                                                </ul>
                                                                                                <div class="clearfix"></div>    
                                                                                            </div>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                }
                                                                                ?>



                                                                                <div class="col-row" style="text-align:left;">
                                                                                    <a href="#">Show earlier messages</a>
                                                                                </div>
                                                                            </div>
                                                                            </div><!--column1-->


                                                                            <!--//Online User Section End Here-->





                                                                            <div class="modal" id="modal-one" aria-hidden="true">
                                                                                <div class="modal-dialog">

                                                                                    <div class="modal-body">


                                                                                    </div><!--//.modal-body-->

                                                                                    <div class="modal-footer">
                                                                                        <a href="#close" class="btn">Close</a>
                                                                                        <!--CHANGED TO "#close"-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>



                                                                            <div class="clearfix"></div>
                                                                            </div>
                                                                            </section>


                                                                            </div>
                                        
                                        
                                                                            <!-- vLine ------------------------------------------->
                                                                            								