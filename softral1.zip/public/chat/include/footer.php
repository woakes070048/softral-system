	<div class="footer">
    	<div class="footer_menu">
        	                                           <a href="<?php echo $websiteOriginalPath;?>pages/help">Escrow Contracts</a>
                                          <a href="<?php echo $websiteOriginalPath;?>pages/privacy-policy">Privacy Policy</a>
                                          <a href="<?php echo $websiteOriginalPath;?>pages/plans-fees-1">Plans &amp; Fees</a>
                                    					<a href="<?php echo $websiteOriginalPath;?>contact">Contact us</a>
        </div>
        <div class="copy">
        	Copyright © 2016 - Softral.com, Powered by Pronoor - All Rights Reserved.
        </div>
    </div>