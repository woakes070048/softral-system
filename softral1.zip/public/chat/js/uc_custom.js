// JavaScript Document

$(document).ready(function()

{

	var currentUrl=isSecure();
	currentUrl=currentUrl+"/blog/helper/ajaxLogin.php";

$(document).on("click","#ucomment_mainSmilyButton",function(){
		$(".uComment_mainSmilyBox").hide();
		$("#ucomment_mainSmilyTable").toggle();

});	



$(document).on("click","#ucomment_mainSmilyTable div.UCSmilise div#comment_ div ul li a",function(){

	var smilyText=$(this).attr("title");

	var message=$("#message").val();

	message=message+smilyText;

	$("#message").val(message);

	$("#message").focus();

});	

	

	

$(document).on("click","div.UCSmilise .imotIon .uComment_subSmily div ul li a",function(){

	var smilyText=$(this).attr("title");

	var selectMessageBox=$(this).attr("data");

	var messageValue=$("#subMessBox_"+selectMessageBox).val();

	messageValue=messageValue+smilyText;

	$("#subMessBox_"+selectMessageBox).val(messageValue);

	$("#subMessBox_"+selectMessageBox).focus();

});	

	

	

	

	

$(document).on("click","div.UCSmilise .imotIon .uComment_mainSmilyClass div ul li a",function(){

	var smilyText=$(this).attr("title");

	var selectMessageBox=$(this).attr("data");

	var messageValue=$("#mainMessBox_"+selectMessageBox).val();

	messageValue=messageValue+smilyText;

	$("#mainMessBox_"+selectMessageBox).val(messageValue);

	$("#mainMessBox_"+selectMessageBox).focus();

});	

	

	

		var response;

		function checkLogin()

		{

			var userId=$("#userId").val();	

			if(userId=="")

			{

			$('#loginModal').modal();

			return false;

			}

			else

			{

			return true;

			}

	

		}

	$("#mainComment").click(function(e)

	{

		var response=checkLogin();

		if(response == true)

		{

		var mainComment=$("#message").val();	

			if(mainComment!="")

			{

				var messBody=$("#message").val();	

				var userId=$("#userId").val();

				var postId=$("#postId").val();

				$.ajax({

					url: currentUrl,

					type: 'POST',

					data: 'uc_comment='+messBody+'&uc_postId='+postId,

					success: function(data) {

					//called when successful

					$("#message").val("");

					$("#ucomment_mainSmilyTable").hide();

					$('#commentdiv').html(data);

				},

				error: function(e) {

								//console.log(e.message);

				}

				});

					

			}

		}

	});

	

	

	  $(document).on("click","a.ucomment_SmilyButton",function(){

		var currentId=$(this).attr('data');

		$("#ucomment_mainSmilyTable").hide();

		$("#ucomment_SmilyTable_"+currentId).toggle();

	});



	  $(document).on("click","a.Mainreply",function(){

		var currentId=$(this).attr('id');

		currentId=currentId.split('_');

		currentId=currentId[1];

		$("#ucomment_mainSmilyTable").hide();

		$(".ucomment_commenSmilyButton").hide();

		$(".uComment_mainSmilyBox").hide();

		$(".uComment_messageBox").hide();

		$(".uComment_submitButton").hide();

		$("#mainMessBox_"+currentId).show();

		$("#mainMessButton_"+currentId).show();

		$("#ucomment_SmilyButton_"+currentId).show();

		

		

	});



	$(document).on("click","a.messboxButton",function(e){

		var commentInputId=$(this).attr("id");

		commnetId=commentInputId.split('_');

		commnetId=commnetId[1];	

		var messBody = $("#mainMessBox_"+commnetId).val();

		if(messBody!="")

		{

			var response=checkLogin();

				if(response == true)

				{

					var reciverId=$(this).attr("data");

						$.ajax({

						  url: currentUrl ,

						  type: 'POST',

						  data: 'commentId='+commnetId+'&comment='+messBody+'&reciverId='+reciverId,

						  success: function(data) {

							//called when successful

							$(".messagebox").val("");

							$(".messagebox").hide();

							$(".messboxButton").hide();

							$(".ucomment_SmilyButton").hide();

							$(".uComment_mainSmily").hide();

							$('#mainSubComment_'+commnetId).html(data);

						  },

						  error: function(e) {

							//called when there is an error

							console.log(e.message);

						  }

						 });

				   }

			  }

		

	});

		



 	$(document).on("click","a.reply",function()

	{	var replayCurrentId = $(this).attr('id');

		replayCurrentId = replayCurrentId.split("_");

		replayCurrentId = replayCurrentId[1];

		$(".ucomment_commenSmilyButton").hide();

		$(".uComment_mainSmilyBox").hide();

		$(".uComment_messageBox").hide();

		$(".uComment_submitButton").hide();

		$("#ucomment_mainSmilyTable").hide();

		$("#subMessBox_"+replayCurrentId).show();

		$("#subMessBoxButton_"+replayCurrentId).show();

		$("#ucomment_subSmilyButton_"+replayCurrentId).show();

	});

		

	$(document).on("click","a.subMessBoxButton",function(e)								  

	{	var replayCurrentId = $(this).attr('id');

		replayCurrentId = replayCurrentId.split("_");

		replayCurrentId = replayCurrentId[1];

		var messBody=$("#subMessBox_"+replayCurrentId).val();		

		if(messBody!="")

		{

				var response=checkLogin();

				if(response == true)

				{

					var reciverId=$(this).attr("name");	

					var commnetId=$(this).attr("data");

					$.ajax({

					  url: currentUrl ,

					  type: 'POST',

					  data: 'commentId='+commnetId+'&comment='+messBody+'&reciverId='+reciverId,

					  success: function(data) {

						//called when successful

						$(".ucomment_SmilyButton").hide();

						$(".uComment_mainSmily").hide();

						$(".subMessBox").val("");	

						$('#mainSubComment_'+commnetId).html(data);

					  },

					  error: function(e) {

						//called when there is an error

						console.log(e.message);

					  }

					  });

					}

				}

			

	});

	

	

$('#login').click(function()

{

		var username=$("#uc_email").val();

		var password=$("#uc_password").val();

		var dataString = 'uc_username='+username+'&uc_password='+password+'&uc_login=login';

			if($.trim(username).length>0 && $.trim(password).length>0)

			{

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			beforeSend: function(){ $("#login").val('Connecting...');},

			success: function(data){

					if($.trim(data))

					{

					location.reload(); 

					}

					else

					{

					$("#login").val('Login')

					$("#error").html("<span style='color:#cc0000'></span> Invalid username and password. ");

					}

				}

			});	

		}

});

	

	

$('#cr_login').click(function()

{

		var email=$("#cr_email").val();

		var name=$("#cr_userName").val();

		var dataString = 'uc_name='+name+'&uc_email='+email+'&cr_login=cr_login';

			if($.trim(email).length>0 && $.trim(name).length>0)

			{

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			beforeSend: function(){ $("#cr_login").val('Connecting...');},

			success: function(data){

					if($.trim(data))

					{

					//window.location.href = "index.php";

					$("#error").html("<span style='color:#cc0000'></span>"+data+" ");

					}

					else

					{

					//Shake animation effect.

					//$('#box').shake();

					$("#cr_login").val('Submit');

					$("#error").html("<span style='color:#cc0000'></span> Invalid username and password. ");

					}

				}

			});	

		}

});

	

	

$(document).on("click","a.deleteComment",function(){

	var deleteId = $(this).attr('data');

		var dataString = 'mainDelete=mainDelete&deleteId='+deleteId;

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			success: function(data){

					$("#mainDiv_"+deleteId).hide();

					$("#mainSubComment_"+deleteId).hide();

				}

			});	

		

});

	

	

$(document).on("click","a.deleteSubComment",function(){

	var deleteId = $(this).attr('data');

		var dataString = 'subDelete=subDelete&deleteId='+deleteId;

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			success: function(data){

					$("#ReplyComment_"+deleteId).hide();

				}

			});	

		

});

	

	

$(document).on("click","a.Like",function(){

var response=checkLogin();

if(response == true)

{

	var commentId = $(this).attr('data');

	var commentType = $(this).attr('name');

	var $currentBox = $(this);

			var dataString = 'view=like&commentId='+commentId+'&commentType='+commentType;

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			success: function(data){

					var likeCount =data.split("_");

						like =likeCount[0];

					var dislike =likeCount[1];

				 $currentBox.find("span").html(like);

				 $currentBox=$currentBox.parent();

				 $currentBox.siblings("li").find("span").html(dislike);

			

				}

			});

}

		

});

	

	

	

	

$(document).on("click","a.DisLike",function(){

var response=checkLogin();

if(response == true)

{

	var commentId = $(this).attr('data');

	var commentType = $(this).attr('name');

	var $currentBox = $(this);

		var dataString = 'view=dislike&commentId='+commentId+'&commentType='+commentType;

	

			$.ajax({

			type: "POST",

			url: currentUrl ,

			data: dataString,

			cache: false,

			success: function(data){

					var likeCount =data.split("_");

						like =likeCount[0];

					var dislike =likeCount[1];

				 $currentBox.find("span").html(dislike);

				 $currentBox=$currentBox.parent();

				 $currentBox.siblings("li").find("span").html(like);

			

				}

			});

	

}

		

});

	

	

	

$(document).on("click","a.postLike",function(){

var response=checkLogin();

if(response == true)

{	

	var postId = $(this).attr('data');

	var $currentBox = $(this);

	if($(this).hasClass('disabled1'))

	{

		var dataString = 'view=like&postId='+postId;

	}

	else

	{

		var dataString = 'view=like&postId='+postId;

	}

	

	$.ajax({

			type: "POST",

			url: "http://drshaikh.org/blog/mainrepaly.php",

			data: dataString,

			cache: false,

			success: function(data){

			var getData=data.split("_");

			var likes=getData[0];

			var dislikes=getData[1];

			 $currentBox.siblings("span.like_num").html(likes);

			 $currentBox.siblings("span.dislike_num").html(dislikes);

			 $currentBox.toggleClass("disabled1");	

				}

			});

	

}

		

});

	

	

	

	

$(document).on("click","a.postDislike",function(){

var response=checkLogin();

if(response == true)

{	

	var postId = $(this).attr('data');

	var $currentBox = $(this);

	if($(this).hasClass('disabled1'))

	{

		var dataString = 'view=dislike&postId='+postId;

	}

	else

	{

		var dataString = 'view=dislike&postId='+postId;

	}

	

	$.ajax({

			type: "POST",

			url: "http://drshaikh.org/blog/mainrepaly.php",

			data: dataString,

			cache: false,

			success: function(data){

			var getData=data.split("_");

			var likes=getData[0];

			var dislikes=getData[1];

			 $currentBox.siblings("span.like_num").html(likes);

			 $currentBox.siblings("span.dislike_num").html(dislikes);

			 $currentBox.toggleClass("disabled1");	

				}

			});

	

}

		

});

	

});





/*window.fbAsyncInit = function() {

	FB.init({

	appId      : '288896917937724', // replace your app id here

	channelUrl : 'http://localhost/latest%20comment%20Project/commentPhp/uc_commentBody.php', 

	status     : true, 

	cookie     : true, 

	xfbml      : true  

	});

};

(function(d){

	var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];

	if (d.getElementById(id)) {return;}

	js = d.createElement('script'); js.id = id; js.async = true;

	js.src = "//connect.facebook.net/en_US/all.js";

	ref.parentNode.insertBefore(js, ref);

}(document));



function FBLogin(){

	FB.login(function(response){

		if(response.authResponse){

			window.location.href = "http://localhost/latest%20comment%20Project/commentPhp/actions.php?action=fblogin&url="+document.URL;

		}

	}, {scope: 'email,user_likes'});

}

function FBLogout(){

	FB.logout(function(response) {

		window.location.href = "index.php";

	});

}

*/





function isSecure()

{

	var serverhostname = location.hostname;

  if ("https:" == document.location.protocol) {

    return "https://"+serverhostname;

	} else {

       return "http://"+serverhostname;



	}

}