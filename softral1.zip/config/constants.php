<?php

return [
    'Skrill_account' => 'dhavaljani1990@gmail.com'
];
