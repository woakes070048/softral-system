<?php

return [

    'search' => [
        'case_insensitive' => true,
        'use_wildcards'    => false,
    ]

];
