@extends('laravel-authentication-acl::client.layouts.base')

@section('title')

Softral - My Profile

@stop

@section('content')

<div class="panel panel-default">

			<div class="panel-body">

			

			<section style="padding-bottom: 50px; padding-top: 50px;">

            <div class="row">

                <div class="col-md-4">

					 @if(!$profile->avatar)

                           <span style="" class="glyphicon glyphicon-user profile_noimage"></span>

                        @else

                           <img src="data:image/jpeg;base64,{!! ( $profile->avatar) !!}" class="img-rounded img-responsive" width='200px' style='border-radius:177px;margin-left: 52px;'>

                        @endif

                    <br>
                    <br>
					@if($feedback_freelancer!=0)
						<div style='text-align:center' class='alert alert-success'><h4>Freelancer score</h4><font color='green'><strong>{{$feedback_freelancer}} out of 5</strong></font></div>
				    @elseif($feedback_employee!=0)
						 <br>
						<div style='text-align:center' class='alert alert-success'><h4>Employee score</h4><font color='green'><strong>{{$feedback_employee}} out of 5</strong></font></div>
					@endif
                    

                </div>

                <div class="col-md-8">
                   

                    <!--<div>

                        <a href="#" class="btn btn-social btn-facebook">

                            <i class="fa fa-facebook"></i>&nbsp; Facebook</a>

                        <a href="#" class="btn btn-social btn-google">

                            <i class="fa fa-google-plus"></i>&nbsp; Google</a>

                        <a href="#" class="btn btn-social btn-twitter">

                            <i class="fa fa-twitter"></i>&nbsp; Twitter </a>

                        <a href="#" class="btn btn-social btn-linkedin">

                            <i class="fa fa-linkedin"></i>&nbsp; Linkedin </a>

                    </div>-->

					 <?php $about_me = 'Nothing Specified Yet'; ?>

				  <?php $skills='No skills selected'; ?>

                    <div class="alert alert-info">
					
				
                         <h2>{!! $profile->first_name!!} {!!$profile->last_name!!} @if($tagline!='')- <font size='3px'>{{$tagline}} @endif</h2>

                            <p><span class="glyphicon glyphicon-map-marker"></span> 														@if($profile->city!=null){!! $profile->city.',' !!}@endif

							@if($profile->state!=null){!! $profile->state.',' !!}@endif

							{!! $profile->country !!}</p>

                            <p><strong>Skills: </strong>

                                @foreach($profile->profile_field as $profile_field)

									@if( $profile_field->profile_field_type_id==3)

										

										<?php $skills = $profile_field->modified_value;		

										?>

										

											<?php break; ?>

									@else

										<?php $skills = 'No skills selected'; ?>

									@endif

									 @endforeach

									 {!!$skills!!}

                            </p>

							
                    </div>

					 <div class="form-group col-md-8 ">

                        <h2>About me</h2>
                        <p>

						@foreach($profile->profile_field as $profile_field)

					@if( $profile_field->profile_field_type_id==2)

						

						<?php $about_me = $profile_field->value; ?>

						

							<?php break; ?>

					@else

						<?php $about_me = 'Nothing Specified Yet'; ?>

					@endif

				  @endforeach

                           {!!$about_me!!}

                        </p>
						
							@if($profile->resume!='')
					<p>
							<h3>Resume</h3>
							<iframe src="http://docs.google.com/viewer?url={!! URL::to('/') !!}/uploads/resume/{!! $profile->resume !!}&embedded=true" width="400" height="400" style="border: none;display:block"></iframe>
							 <a href="{!! URL::to('/') !!}/uploads/resume/{!! $profile->resume !!}" target='_blank'>Download Resume</a>
							</p>
					@endif
							


                    </div>

                </div>

				

				  	 <div class="col-md-12">	   	

				<div class="row selected-classifieds">
@if(!empty($profile->jobs))
		  			<h4 style='padding-left: 15px'><strong>My Jobs</strong></h4>

		 	 @foreach($profile->jobs as $job)

            <div class="col-lg-12 user_profile">

              <div class="thumbnail">

			                  <div class="caption">

                  <h4><strong><a href="{!! URL::to('/job/').'/'.$job->slug !!}">{!! $job->project_name !!}</a></strong></h4>

				 <div class="price">Budget: ${!! $job->budget !!} - Posted {!!  $job->created_at !!}</div>&nbsp; | 

				 @if($job->job_close==0)

					Hiring Open 

				 @else

					 Hiring Closed

				 @endif

				<div class="pull-right posted_by"><span style="color: #AFAFAF; ">Total Proposals: </span> ({!! count($job->proposals)!!})</div><br>

				

				  @if(isset($job->categories->category))<div class="pull-left categories"><span style="color: #AFAFAF; ">Category:</span> <a href="{!! URL::to('/category/').'/'.$job->categories->slug !!}"   >{!!  $job->categories->category !!}</a> </div> @endif

				   				  <div class="pull-right skills"><span style="color: #AFAFAF; ">Skills:</span>{!! $job->modified_skill_id !!}</div>

				                   </div>

              </div>

            </div>

			@endforeach
			@else					   		 
<h4 style='padding-left: 15px'><strong>You haven't posted any job yet.</strong></h4>        
@endif
		
			</div>
	

            </div>

            <!-- ROW END -->


        </section>

              </div><!--/panel-body-->

          </div><!--/panel-->

	

	  @stop