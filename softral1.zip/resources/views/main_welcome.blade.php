@extends('laravel-authentication-acl::client.layouts.base-fullscreen')
@section('title')
Softral - Welcome to Softral
@stop
@section('content')

	<div class="gallary">
    	<div class="row">
		 @if($errors->any())
			<div class="alert alert-danger">
				@foreach($errors->all() as $error)
					<p>{{ $error }}</p>
				@endforeach
			</div>
		@endif
        	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				
                <div class="hexa-section" style='background: url("{!! URL::to('/') !!}/uploads/{!!$hexa_gonal_background->image!!}") no-repeat;background-size: 900px 1000px;'>
                	
				<div class="honeycombs">
					@foreach($freelancers as $freelancer)
						@if(isset($freelancer->user_profile[0]->profile_field_type_tagline->value) && $freelancer->user_profile[0]->avatar!='')
								<a href="{!! URL::to('/user/profile').'/'.$freelancer->user_profile[0]->slug !!}" title="{!! $freelancer->user_profile[0]->first_name !!}"><div class="comb"> 
							<img src="data:image/jpeg;base64,{!! ( $freelancer->user_profile[0]->avatar) !!}" />
								<span>{!!$freelancer->user_profile[0]->first_name!!} <br/><br/><p>{!! $freelancer->user_profile[0]->profile_field_type_tagline->value!!}</p></span>           
							</div></a>      
						@endif
					@endforeach             
                 </div>
				 
                	
					<ul id="categories" class="clr">
					<?php $j=0; ?>
					@foreach($freelancers as $key=>$value)
						@if(($value->user_profile[0]->avatar!=''))
							
						 @if($j==0 || $j==1 || $j==3 || $j==6 || $j==10 || $j==15 || $j==21)
							<div class="pusher2">
						 @endif
							<a href="{!! URL::to('/user/profile').'/'.$value->user_profile[0]->slug !!}" title="{!! $value->user_profile[0]->first_name !!}">
							@if($j!=2 && $j!=1)
								<li class='pusher{{$j+1}}'>
						    @else
								<li>
						    @endif
						   
                                <div>
                                    <img src="data:image/jpeg;base64,{!! ( $value->user_profile[0]->avatar) !!}" alt=""/>
                                    <h1>{!!$value->user_profile[0]->first_name!!}</h1>
									<p>@if(isset($value->user_profile[0]->profile_field_type_tagline->value)){!!($value->user_profile[0]->profile_field_type_tagline->value) !!} @else Freelancer @endif</p>
                                </div>
                            </li></a>
						@if($j==0 || $j==2 || $j==5 || $j==9 || $j==14 || $j==20 || $j==27)
							</div>
						@endif
							<?php $j++; ?>
						@endif
					 @endforeach
					</ul>	
					
               	</div>
           	</div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            	<div class="news-section">
				
				@if(!empty($employeer_news->children_hexa))
                	<div class="news">
                	<h3>News</h3>
                    <marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="10" scrolldelay="500">
					 @foreach($employeer_news->children_hexa as $emp_news)
                    	<a href="{!! URL::to('/') !!}/pages/{!!$emp_news->slug!!}">{!!$emp_news->title!!}</a>
					 @endforeach
                    </marquee>                    
                </div>
				@endif
				
				@if(!empty($freelancer_news->children_hexa))
                	<div class="news">
                	<h3>IT News</h3>
                    <marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="10" scrolldelay="500">
                    	 @foreach($freelancer_news->children_hexa as $free_news)
                    	<a href="{!! URL::to('/') !!}/pages/{!!$free_news->slug!!}">{!!$free_news->title!!}</a>
					 @endforeach
                    </marquee>                    
                </div>
				@endif
                </div>
            </div>
        </div>
   
  	  <div class="dummy_text">
    	<h1>About Us</h1>
    	
        	{!!$about['content'] !!}
        
    </div>


@stop